<?php

$lang['first_name_is_required'] = 'First name is required';

$lang['first_name'] = 'First name';

$lang['last_name_is_required'] = 'Last name is required';

$lang['last_name'] = 'Last name';

$lang['username_is_required'] = 'Username is required';

$lang['username'] = 'Username';

$lang['valid_email_is_required'] = 'Valid email is required';

$lang['email'] = 'Email';

$lang['password_is_required'] = 'Password is required';

$lang['repeat_password_is_required'] = 'Repeat password is required';

$lang['repeat_password'] = 'Repeat password';

$lang['address_is_required'] = 'Address is required';

$lang['address'] = 'Address';

$lang['country_is_required'] = 'country is required';

$lang['country'] = 'Country';

$lang['state_is_required'] = 'State is required';

$lang['state'] = 'State';

$lang['paypal_email_is_required'] = 'Paypal Email is required';

$lang['paypal_email'] = 'Paypal Email';

$lang['phone_number_is_required'] = 'Phone Number is required';

$lang['phone_number'] = 'Phone Number';

$lang['alternate_phone_number_is_required'] = 'Alternate Phone Number is required';

$lang['alternate_phone_number'] = 'Alternate Phone Number';

$lang['i_accept_the_terms_of_the'] = 'I accept the terms of the';

$lang['affiliate_policy'] = 'Affiliate policy';

$lang['password'] = 'Password';

$lang['sign_in'] = 'Sign in';

$lang['sign_up'] = 'Sign up';

$lang['forget_password'] = 'Forget password';

$lang['registered_email'] = 'Registered email';

$lang['send_mail'] = 'Send mail';

$lang['back_login'] = 'Back login';

$lang['privacy_policy'] = 'Privacy policay';

$lang['close'] = 'Close';