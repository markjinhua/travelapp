<?php

$lang['features'] = 'features';

$lang['amazing_features'] = 'Amazing Features';

$lang['user_friendly'] = 'User Friendly';

$lang['user_friendly_des'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing typesting industry text.';

$lang['super_fast_speed'] = 'Super Fast Speed';

$lang['super_fast_speed_des'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing typesting industry text.';

$lang['24_7_support'] = '24/7 Support';

$lang['24_7_support_des'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing typesting industry text.';

$lang['secure'] = 'Secure';

$lang['secure_des'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing typesting industry text.';

$lang['awesome_rating'] = 'Awesome Rating';

$lang['awesome_rating_des'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing typesting industry text.';

$lang['award_winning'] = 'Award Winning';

$lang['award_winning_des'] = 'Lorem ipsum dolor sit amet, consectetur adipisicing typesting industry text.';

$lang['watch_video'] = "Watch Video";

$lang['how_it_works'] = "How It Works?";

$lang['our_app_is_amazing'] = "Our App Is Amazing!";

$lang['our_app_is_amazing_desc'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive e-tailers after sustainable total linkage.";

$lang['read_more'] = "Read More";

$lang['update'] = "Update";

$lang['free_updates!'] = "Free Updates!";

$lang['free_updates_desc'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive e-tailers after sustainable total linkage.";

$lang['read_more'] = "Read More ";

$lang['screenshots'] = "Screenshots";

$lang['app_screens'] = "App Screens";

$lang['team'] = "Team";

$lang['our_expert_team'] = "Our Expert Team";

$lang['ux_consultant'] = "UX Consultant";

$lang['jhon_deo'] = "Jhon Deo";

$lang['web_developer'] = "Web Developer";

$lang['jhon_smith'] = "Jhon Smith";

$lang['ui/ux_designer'] = "UI/UX Designer";

$lang['elina_dcruz'] = "Elina Dcruz";

$lang['digital_marketer'] = "Digital Marketer";

$lang['reviews'] = "Reviews";

$lang['clients_who_loved_us'] = "Clients Who Loved Us";

$lang['clients_who_loved_us_desc'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive. Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthu.";

$lang['uideck'] = "UIdeck";

$lang['uideck_desc'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive. Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthu.";

$lang['tesla_motors'] = "Tesla Motors";

$lang['tesla_motors_desc'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive. Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthu.";

$lang['envato_customer'] = "Envato Customer";

$lang['envato_customer_desc'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive. Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthu.";

$lang['mark_parker'] = "Mark Parker";

$lang['graygris_inc'] = "GrayGris Inc.";

$lang['graygris_inc_sec'] = "Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive. Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthu.";

$lang['alex_dattilo'] = "- Alex Dattilo";

$lang['ceo_optima_inc'] = "CEO Optima Inc";

$lang['subscribe_for_more_features'] = 'Subscribe For More Features';

$lang['subscribe_for_more_features_desc'] = 'Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive.';

$lang['subscribe'] = 'Subscribe';

$lang['our_pricing_plan'] = 'Our Pricing Plan';

$lang['free'] = 'Free';

$lang['2_gb_storage'] = '2 GB Storage';

$lang['single_user'] = 'Single User';

$lang['minimal_features'] = 'Minimal Features';

$lang['1000_logs'] = '1000 Logs';

$lang['standard'] = 'Standard';

$lang['10_gb_hosting'] = '10 GB Hosting';

$lang['5_users'] = '5 Users';

$lang['sales_dashboard'] = 'Sales Dashboard';

$lang['50000_logs'] = '50,000 Logs';

$lang['business'] = 'Business';

$lang['free_installation'] = 'Free Installation';

$lang['50_gb_hosting'] = '50 GB Hosting';

$lang['unlimited_users'] = 'Unlimited Users';

$lang['sales_and_marketing_dashbaord'] = 'Sales and Marketing Dashbaord';

$lang['premium_features'] = 'Premium Features';

$lang['unlimited_logs'] = 'Unlimited Logs';

$lang['mo'] = 'mo';

$lang['download_our_app_from_store'] = 'Download Our App From Store';

$lang['download_our_app_from_store_desc'] = 'Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive.';

$lang['from_playstore'] = 'From PlayStore';

$lang['from_appstore'] = 'From AppStore';

$lang['blog'] = 'Blog';

$lang['recent_news'] = 'Recent News';

$lang['how_proton_will_transform_your_business'] = 'How Proton Will Transform Your Business';

$lang['20_growth_hacking_tips_from_experts'] = '20 Growth Hacking Tips from Experts';

$lang['proton_has_been_launched_get_started!'] = 'Proton Has Been Launched, Get Started!';

$lang['posted_by_admin'] = 'Posted by Admin';

$lang['10_april_2020'] = '10 April, 2020';

$lang['love_to_hear_from_you'] = 'Love to Hear From You';

$lang['submit'] = 'Submit';

$lang['title'] = 'Proton - Bootstrap 4 Template';

$lang['features'] = 'Features';

$lang['screenshots'] = 'Screenshots';

$lang['testimonial'] = 'Testimonial';

$lang['plans'] = 'Plans';

$lang['download'] = 'Download';

$lang['contact'] = 'Contact';

$lang['register'] = 'Register';

$lang['slider_title'] = 'Get Your App Landing Page <br> With Proton Template';

$lang['slider_desc'] = 'lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse unde blanditiis nostrum mollitia aliquam sed. Numquam ipsum unde repellendus similique autem non ab quibusdam enim provident distinctio! Fugit tenetur, iusto.';

$lang['download_now'] = 'Download Now';

$lang['get_started'] = 'Get Started';

$lang['slider_desc2'] = 'Appropriately implement one-to-one catalysts for change vis-a-vis wireless catalysts for change. Enthusiastically architect adaptive.';

$lang['create_a_free_account'] = 'Create a Free Account';

$lang['sign_in'] = 'Sign In';

$lang['log_in'] = 'Log In';

$lang['about'] = 'About';

$lang['about_us'] = 'About Us';

$lang['pricing'] = 'Pricing';

$lang['jobs'] = 'Jobs';

$lang['resource'] = 'Resource';

$lang['comunnity'] = 'Comunnity';

$lang['become_a_partner'] = 'Become a Partner';

$lang['our_technology'] = 'Our Technology';

$lang['documentation'] = 'Documentation';

$lang['support'] = 'Support';

$lang['terms_condition'] = 'Terms & Condition';

$lang['contact_us'] = 'Contact Us';

$lang['privacy_policy'] = 'Privacy Policy';

$lang['help'] = 'Help';

$lang['2020_designed_by'] = '&copy; 2020 - Designed by';

$lang['uideck'] = 'UIdeck';

$lang['home'] = 'Home';

$lang['sign_up'] = 'Sign Up';

$lang['login'] = 'Login';

$lang['correct_invalid_value'] = 'Please, correct invalid values.';

$lang['username_email'] = 'Username or Email';

$lang['email'] = 'Email';

$lang['forget_password'] = 'Forget Password';

$lang['forgot_your_password'] = 'Forgot your password?';

$lang['reset_your_password'] = 'Reset Your Password';

$lang['Please_enter_your_email_address_and_we_will_send_you_a_password_password_link'] = 'Please enter the email address you registered with and a password reset link will be sent to you';

$lang['insert_email'] = 'Email';

$lang['send_reset_link'] = 'Send Reset Link';

$lang['back_to_login'] = 'Back To Login';

$lang['back_to_register'] = 'Back To Register';

$lang['Use_your_credentials_to_login_into_account'] = 'Use your credentials to login into account';

$lang['enter_your_information_to_setup_a_new_account'] = 'Enter your information to setup a new account';

$lang['reset_password'] = 'Reset Password';

$lang['dont_have_an_account'] = 'Dont have an account?';

$lang['password'] = 'Password';

$lang['dont_have_an_account_yet'] = 'Dont have an account yet?';

$lang['already_have_an_account'] = 'Already have an account?';

$lang['have_an_account'] = 'Have an Account? Login now';

$lang['create_account'] = 'Create Account?';

$lang['temrs_of_use'] = 'Terms of use';

$lang['my_store'] = 'Marketplace';

$lang['contact_us_for_any_question'] = 'Contact Us For Any Question';

$lang['contact_form'] = 'Contact Form';

$lang['first_name'] = 'First name';

$lang['last_name'] = 'Last name';

$lang['mobile'] = 'Mobile';

$lang['subject'] = 'Subject';

$lang['message'] = 'Message';

$lang['terms_n_conditions'] = 'Terms and Conditions';

$lang['please_check_terms'] = 'Please check to agree Terms & Conditions';

$lang['send'] = 'Send';

$lang['contact_info'] = 'Contact info';

$lang['phone'] = 'Phone';

$lang['addres'] = 'Addres';

$lang['social_media'] = 'Social media';

$lang['faq'] = 'Faq';

$lang['faq_title'] = 'Frequently Asked Questions';

$lang['terms'] = 'Terms';

$lang['copyright_all_rights_reserved'] = 'Copyright © All Rights Reserved';

$lang['back_to_homepage'] = 'Back to homepage';

$lang['join_as_affiliate'] = 'Join As Affiliate';

$lang['best_affiliate_plan'] = 'Best Affiliate Plan';

$lang['lifetime'] = 'Lifetime';

$lang['days'] = 'Days';

$lang['save'] = 'Save';

$lang['per_monthly'] = 'Per monthly';

$lang['image'] = 'Image';

$lang['featured_image'] = 'Featured Image';

$lang['login_image'] = 'Login Image';

$lang['watch_our_videos'] = 'Watch Our Videos';

$lang['play'] = 'Play';

$lang['sign_up_new'] = 'Sign Up';

$lang['question'] = 'Question';

$lang['internal_page'] = 'Internal page';

$lang['i_am_already_a_member'] = "I'm Already a Member!";

$lang['bonus_rate'] = 'Bonus rate';

$lang['first_name_is_required'] = 'First name is required';

$lang['last_name_is_required'] = 'Last name is required';

$lang['username_is_required'] = 'Username is required';

$lang['username'] = 'Username';

$lang['valid_email_is_required'] = 'Valid email is required';

$lang['password_is_required'] = 'Password is required';

$lang['repeat_password_is_required'] = 'Repeat password is required';

$lang['repeat_password'] = 'Repeat password';

$lang['address_is_required'] = 'Address is required';

$lang['address'] = 'Address';

$lang['country_is_required'] = 'country is required';

$lang['country'] = 'Country';

$lang['state_is_required'] = 'State is required';

$lang['state'] = 'State';

$lang['paypal_email_is_required'] = 'Paypal Email is required';

$lang['paypal_email'] = 'Paypal Email';

$lang['phone_number_is_required'] = 'Phone Number is required';

$lang['phone_number'] = 'Phone Number';

$lang['alternate_phone_number_is_required'] = 'Alternate Phone Number is required';

$lang['alternate_phone_number'] = 'Alternate Phone Number';

$lang['i_accept_the_terms_of_the'] = 'I accept the terms of the';

$lang['affiliate_policy'] = 'Affiliate policy';

$lang['registered_email'] = 'Registered email';

$lang['email_address'] = 'Email address';

$lang['send_mail'] = 'Send mail';

$lang['back_login'] = 'Back login';

$lang['close'] = 'Close';

$lang['logo'] = 'Logo';

$lang['icon'] = 'Icon';

$lang['flag'] = 'Flag';

$lang['arrow'] = 'Arrow';

$lang['loading'] = 'Loading';

$lang['required'] = 'required';

$lang['affiliate'] = 'Affiliate';

$lang['vendor'] = 'Vendor';

$lang['client'] = 'Client';

$lang['video'] = 'Video';

$lang['faq_question_if_not_exist'] = 'Where can I get some';

$lang['select_state'] = 'Select State';

$lang['charge_for_order'] = 'Charge for Order';

$lang['affiliate_commission'] = 'Affiliate commission:';

$lang['default'] = 'Default';

$lang['faq_answer_if_not_exist'] = "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.";

$lang['login_content_if_not_exist'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

$lang['register_content_if_not_exist'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

$lang['terms_content_if_not_exist'] = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";