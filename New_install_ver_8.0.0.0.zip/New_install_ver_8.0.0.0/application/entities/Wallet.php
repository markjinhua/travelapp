<?php
namespace App;
class Wallet extends \Illuminate\Database\Eloquent\Model
{
	public $timestamps = false;
	public $table = 'wallet';
}