<?php
namespace App;
class Slug extends \Illuminate\Database\Eloquent\Model
{
	public $table = 'slugs';
	public $timestamps = false;
}