<?php
namespace App;
class Setting extends \Illuminate\Database\Eloquent\Model
{
	public $table = 'setting';
	public $timestamps = false;
}