<?php
namespace App;
class Product extends \Illuminate\Database\Eloquent\Model
{
	public $table = 'product';
	public $timestamps = false;
}