<?php
namespace App;
class Notification extends \Illuminate\Database\Eloquent\Model
{
	public $timestamps = false;
	public $table='notification';
}