<!DOCTYPE html>
<html lang="en">
<head>
    <title>Php Error</title>
    <link rel="stylesheet" type="text/css" href="<?= '../assets/css/404-css.css'; ?>">
</head>
<body>
     <div id="clouds">
        <div class="cloud x1"></div>
        <div class="cloud x1_5"></div>
        <div class="cloud x2"></div>
        <div class="cloud x3"></div>
        <div class="cloud x4"></div>
        <div class="cloud x5"></div>
    </div>
    <div class='c'>
        <div class='_404'>Php Error</div>
        <hr>
        <br>
        <br>
        <div class='_1'><?php echo $heading = "Php Error"; ?></div><br>
        
        <div class='_2'><?php echo $message = "Please error goes here .."; ?></div><br>
         
    </div>

</body>
</html> 