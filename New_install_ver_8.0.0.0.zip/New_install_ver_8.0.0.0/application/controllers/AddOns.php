<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);


class AddOns extends MY_Controller {
	function __construct() {
		parent::__construct();
// 		$this->load->model('user_model', 'user');
// 		$this->load->model('Product_model');
// 		$this->load->model('Report_model');
// 		$this->load->model('IntegrationModel');
		___construct(1);
	}
}

